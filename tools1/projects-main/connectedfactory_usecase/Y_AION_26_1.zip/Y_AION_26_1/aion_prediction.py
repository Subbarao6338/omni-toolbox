import warnings
warnings.filterwarnings("ignore")
import json
import os
import sys
import pandas as pd
from pandas.io.json import json_normalize
from selector import selector
from inputprofiler import inputprofiler
from trained_model import trained_model
from output_format import output_format
def predict(data):
    try:
        if os.path.splitext(data)[1] == ".tsv":
            df=pd.read_csv(data,encoding='utf-8',sep='\t')
        elif os.path.splitext(data)[1] == ".csv":
            df=pd.read_csv(data,encoding='utf-8')
        else:
            if os.path.splitext(data)[1] == ".json":
                with open(data,'r',encoding='utf-8') as f:
                    jsonData = json.load(f)
            else:
                jsonData = json.loads(data)
            df = json_normalize(jsonData)
        df0 = df.copy()
        profilerobj = inputprofiler()
        df = profilerobj.apply_profiler(df)
        selectobj = selector()
        df = selectobj.apply_selector(df)
        modelobj = trained_model()
        output = modelobj.predict(df,"")
        outputobj = output_format()
        output = outputobj.apply_output_format(df0,output)
        print("predictions:",output)
        return(output)
    except KeyError as e:
        output = {"status":"FAIL","message":str(e).strip('"')}
        print("predictions:",json.dumps(output))
        return (json.dumps(output))
    except Exception as e:
        output = {"status":"FAIL","message":str(e).strip('"')}
        print("predictions:",json.dumps(output))
        return (json.dumps(output))
if __name__ == "__main__":
	output = predict(sys.argv[1])