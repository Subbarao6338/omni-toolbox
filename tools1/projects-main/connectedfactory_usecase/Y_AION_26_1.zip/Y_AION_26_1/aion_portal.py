import dash
import dash_html_components as html
import dash_core_components as dcc
import plotly.graph_objects as go
import plotly.figure_factory as ff
import dash_bootstrap_components as dbc
from plotly.subplots import make_subplots
import dash_dangerously_set_inner_html
from sklearn.metrics import confusion_matrix 
import pandas as pd
import numpy as np
import plotly.express as px
import json
import base64
import dash_table
from dash.dependencies import Input, Output
from sklearn.linear_model import Lasso, LogisticRegression
from sklearn.feature_selection import SelectFromModel
from sklearn.ensemble import ExtraTreesClassifier
from facets_overview.generic_feature_statistics_generator import GenericFeatureStatisticsGenerator
def create_card(title, content):
    card = dbc.Card(
        dbc.CardBody(
            [
                html.H4(title, className="card-title"),
                html.H3(content, className="card-subtitle"),
                html.Br(),
                ]
        ),
        color="info", 
		inverse=True,
    )
    return(card)
	
fig = go.FigureWidget()

visualization_json = 'display.json'
with open(visualization_json) as f:
	config = json.load(f)
	
dataPath = config['preprocessedData']
df = pd.read_csv(dataPath)
dataPath = config['postprocessedData']
postdf = pd.read_csv(dataPath)
data_json = df.to_json(orient='records')
dataPath = config['datasetAnalysis']
datasetdf = pd.read_csv(dataPath)
datasetdf = datasetdf.set_index('Unnamed: 0') 
datasetdf = datasetdf[['count','mean','std','min','max']] 

if 'correlationAnalysis' in config:
	dataPath = config['correlationAnalysis']
	cor_mat = pd.read_csv(dataPath,index_col=0)
	cor_mat = cor_mat.round(1)
	z = cor_mat.values.tolist()
	fig = ff.create_annotated_heatmap(z, x=cor_mat.columns.tolist(), y=cor_mat.index.tolist(),annotation_text= z, colorscale='Blues')
	fig.layout.yaxis.automargin = True
	fig.layout.title = 'Features Correlation'

mp_output=[]
if config['problemType'].lower() == 'classification':
	if 'ConfusionMatrix' in config:
		conf_mat = config['ConfusionMatrix']
		conf_mat = pd.DataFrame.from_dict(conf_mat)
		z = conf_mat.values.tolist()
		cmfig = ff.create_annotated_heatmap(z, x=conf_mat.columns.tolist(), y=conf_mat.index.tolist(),annotation_text= z, colorscale='Blues')
		mp_output.append(dcc.Graph(figure=cmfig,className="one-third column"))
	roc = config['ROC_AUC_CURVE']

	for x in roc:
		class_name = x['class']
		xaxis = x['FP'].split(',')
		yaxis = x['TP'].split(',')
		rocfig = go.FigureWidget()
		linegraph = rocfig.add_scatter(y=yaxis,x=xaxis,line_color="orange");
		rocfig.layout.xaxis.title = 'False Positive Rate'
		rocfig.layout.yaxis.title = 'True Positive Rate'
		rocfig.layout.yaxis.automargin = True
		rocfig.layout.title = 'ROC AUC - Class: '+class_name
		mp_output.append(dcc.Graph(figure=rocfig,className="one-third column"))

	recall_precision = config['PRECISION_RECALL_CURVE']
	for x in recall_precision:
		class_name = x['class']
		xaxis = x['Recall'].split(',')
		yaxis = x['Precision'].split(',')
		rocfig = go.FigureWidget()
		rocfig.layout.xaxis.title = 'Recall'
		rocfig.layout.yaxis.title = 'Precision'
		rocfig.add_scatter(y=yaxis,x=xaxis,line_color="orange");
		rocfig.layout.yaxis.automargin = True
		rocfig.layout.title = 'PRECISION RECALL - Class: '+class_name
		mp_output.append(dcc.Graph(figure=rocfig,className="one-third column"))
else:
		dataPath = config['predictedData']
		predict_df = pd.read_csv(dataPath)
		regfig = go.Figure()
		regfig.add_trace(go.Scatter(x=np.arange(1, len(predict_df)+1), y=predict_df['actual'],
                    mode='lines',
                    name='Actual'))
		regfig.add_trace(go.Scatter(x=np.arange(1, len(predict_df)+1), y=predict_df['predict'],
                    mode='lines',
                    name='Predict'))
		mp_output.append(dcc.Graph(figure=regfig))
		
output = []
i = 0
distributionlist = config['features_distribution']
distributionlist = pd.DataFrame.from_dict(distributionlist)
#### BUSINESS CHARTS #######
business_output = []
business_output.append(html.Br())
card1 = create_card('Problem Type',str(config['problemType']).upper())
card2 = create_card('Model Features',str(config['modelFeatures']))
card3 = create_card('Empty Features',str(config['emptyFeatures']))
business_output.append(dbc.Row([dbc.Col(card1),dbc.Col(card2),dbc.Col(card3)], className="mb-4",))
if config['problemType'].lower() == 'classification':
	xaxis = config['targetFeature']
	dfp = postdf.copy()
	dfp['t_Counts'] = np.zeros(len(dfp))
	df2 = dfp.groupby(xaxis, as_index=False).count()
	labels = df2[xaxis].tolist()
	values = df2['t_Counts'].tolist()
	bfig = go.Figure(data=[go.Pie(labels=labels, values=values, textinfo='label+percent')])
	bfig.update_layout(title="Class Vs Count")
	#blayout = {"title":dict(text ="Sentiment Analysis",font =dict(size=20,color = 'white'))}
	business_output.append(html.Div(dcc.Graph(figure=bfig),style={'width': '48%','display': 'inline-block'}))
	selector = SelectFromModel(ExtraTreesClassifier())
	xtrain=postdf[config['modelFeatures']]
	ytrain=postdf[config['targetFeature']]
	selector.fit(xtrain,ytrain)
	values = selector.estimator_.feature_importances_
	labels = config['modelFeatures']
	new = pd.DataFrame({
		'col_label': labels,
		'col_values': values
	})
	new = new.sort_values(
		by='col_values',
		ascending=True)
	bfig = go.Figure([go.Bar(x=new['col_values'],y=new['col_label'],orientation = 'h',)])
	bfig.update_layout(title="Features Importance")
	bfig.update_layout(barmode='stack', xaxis={'categoryorder':'category ascending'})
	business_output.append(html.Div(dcc.Graph(figure=bfig),style={'width': '48%', 'align': 'right', 'display': 'inline-block'}))
	
#### BUSINESS CHARTS END #######

visualization_charts = config['features_graphs']
numberofRows=0
for x in visualization_charts:
	if 'numberofcharts' in x:
		numberofcharts = x['numberofcharts']
		numberofRows = int((numberofcharts/3))+1
		
height = numberofRows*300

ffig = make_subplots(rows=numberofRows, cols=3)
row = 1
col = 1



for x in visualization_charts:
	if 'x_feature' not in x:
		continue
	xaxis = x['x_feature']
		
	if 'bar_charts' in x:
		yaxis = 'Count'
		df['t_Counts'] = np.zeros(len(df))
		df2 = df.groupby(xaxis, as_index=False).count()
		xaxis_data = df2[xaxis].tolist()
		yaxis_data = df2['t_Counts'].tolist()
		ffig.add_trace(go.Bar(x=xaxis_data, y=yaxis_data, name=xaxis), row=row, col=col)
		ffig.update_xaxes(title_text=xaxis, row=row, col=col)
		ffig.update_yaxes(title_text='Count', row=row, col=col)
		col += 1
		if col == 4:
			col = 1
			row += 1

for x in visualization_charts:
	if 'x_feature' not in x:
		continue
	xaxis = x['x_feature']
		
	if 'bar_charts' in x:		
		for y in x['bar_charts']:
			yaxis = y['y_feature']
			df2 = df.groupby(xaxis, as_index=False)[yaxis].mean()
			xaxis_data = df2[xaxis].tolist()
			yaxis_data = df2[yaxis].tolist()
			ffig.add_trace(go.Bar(x=xaxis_data, y=yaxis_data,name=yaxis), row=row, col=col)
			ffig.update_xaxes(title_text=xaxis, row=row, col=col)
			ffig.update_yaxes(title_text=yaxis, row=row, col=col)
			col += 1
			if col == 4:
				col = 1
				row += 1
			'''
			output.append(dcc.Graph(id=xaxis+'_'+yaxis+'_graph_id',figure={'data':[{'x': xaxis_data, 'y': yaxis_data, 'type': 'bar', 'name': 'Mean'},],'layout': {'title': 'Pair Graph:'+str(xaxis)+' '+str(yaxis)}}))
			'''
	if 'line_charts' in x:
		for y in x['line_charts']:
			yaxis = y['y_feature']
			print(xaxis)
			print(yaxis)
			df2 = df.groupby(xaxis, as_index=False)[yaxis].mean()
			xaxis_data = df2[xaxis].tolist()
			yaxis_data = df2[yaxis].tolist()
			ffig.add_trace(go.Scatter(x=xaxis_data, y=yaxis_data,name=xaxis), row=row, col=col)
			col += 1
			if col == 4:
				col = 1
				row += 1
for x in visualization_charts:
	if 'index_line_feature' in x:
		for y in x['index_line_feature']:
			yaxis = y['y_feature']
			x_data = np.arange(1, len(df)+1)
			ffig.add_trace(go.Scatter(x=x_data, y=df[yaxis],name=yaxis), row=row, col=col)
			ffig.update_xaxes(title_text="Seq.No", row=row, col=col)
			ffig.update_yaxes(title_text=yaxis, row=row, col=col)
			col += 1
			if col == 4:
				col = 1
				row += 1
				
	ffig.update_layout(title_text="Features Pair Plot", height=height,showlegend=False)



				   
external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css',dbc.themes.BOOTSTRAP]

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
#app = dash.Dash(__name__)
gfsg = GenericFeatureStatisticsGenerator()
proto = gfsg.ProtoFromDataFrames([{'name': 'train', 'table': df}])
protostr = base64.b64encode(proto.SerializeToString()).decode("utf-8")

tabs_styles = {
    'height': '44px'
}
tab_style = {
    'borderBottom': '1px solid #d6d6d6',
    'padding': '6px',
	'backgroundColor': '#e5e2e0',
    'fontWeight': 'bold',
	'fontSize':14
}

tab_selected_style = {
    'borderTop': '1px solid #d6d6d6',
    'borderBottom': '1px solid #d6d6d6',
    'backgroundColor': '#119DFF',
    'color': 'white',
	'fontWeight': 'bold',
    'padding': '6px',
	'fontSize':14
}

app.title = 'AION'
business_view = html.Div([
    dcc.Tabs([
		dcc.Tab(label='DASHBOARD', children=[
            html.Div(html.Div(children=business_output,style={'width': '100%', 'display': 'inline-block'}))
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='DATA OVERVIEW', children=[
            html.Div(html.Div(children=[
				html.Iframe(
					width="100%",
					height="800",
					srcDoc= """
					<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"></script>
					<link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/1.0.0/facets-dist/facets-jupyter.html" >
					<facets-overview id="elem"></facets-overview>
					<script>
						document.querySelector("#elem").protoInput = "{protostr}";
					</script>""".format(protostr=protostr)
				),
			]))
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='FEATURES ANALYSIS', children=[
           dcc.Graph(figure=ffig,className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		
		 dcc.Tab(label='CORRELATION ANALYSIS', children=[
            dcc.Graph(figure=fig,className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='MODEL PERFORMANCE', children=[
            html.Div(html.Div(children=mp_output),className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		
    ],style=tabs_styles)
])

datascience_view = html.Div([
    dcc.Tabs([
		dcc.Tab(label='DATA OVERVIEW', children=[
            html.Div(html.Div(children=[
				html.Iframe(
					width="100%",
					height="800",
					srcDoc= """
					<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"></script>
					<link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/1.0.0/facets-dist/facets-jupyter.html" >
					<facets-overview id="elem"></facets-overview>
					<script>
						document.querySelector("#elem").protoInput = "{protostr}";
					</script>""".format(protostr=protostr)
				),
			]))
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='FEATURES ANALYSIS', children=[
           dcc.Graph(figure=ffig,className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		
		 dcc.Tab(label='CORRELATION ANALYSIS', children=[
            dcc.Graph(figure=fig,className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='DATA DEEP DIVE', children=[
            html.Div(children=[
				html.Iframe(
					width="100%",
					height="800",
					srcDoc="""
					<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.3.3/webcomponents-lite.js"></script>
					<link rel="import" href="https://raw.githubusercontent.com/PAIR-code/facets/1.0.0/facets-dist/facets-jupyter.html" >
					<facets-dive id="elem" height="800"></facets-dive>
					<script>
						var data = {jsonstr};
						document.querySelector("#elem").data = data;
					</script>""".format(jsonstr=data_json)
				),
			])
        ],style=tab_style,selected_style=tab_selected_style),
		dcc.Tab(label='MODEL PERFORMANCE', children=[
            html.Div(html.Div(children=mp_output),className="row")
        ],style=tab_style,selected_style=tab_selected_style),
		
    ],style=tabs_styles)
])

app.layout = html.Div([ html.H1("AION VISUALIZER"),html.Br(),
    dcc.Dropdown(
        id='demo-dropdown',
        options=[
            {'label': 'Business View', 'value': 'BV'},
            {'label': 'Data Science View', 'value': 'DSV'}
        ],
		style = {
			'width':'40%',
			'display':'inline-block',
			'verticalAlign':"middle",
			'fontSize':16
		},
        value='BV'
    ),
	html.Br(),
    html.Div(id='dd-output-container')
])


@app.callback(
    dash.dependencies.Output('dd-output-container', 'children'),
    [dash.dependencies.Input('demo-dropdown', 'value')])
def update_output(value):
	if	value == 'BV':
		return (business_view)
	else:
		return (datascience_view)
	
if __name__ == '__main__':
    app.run_server(debug=True)