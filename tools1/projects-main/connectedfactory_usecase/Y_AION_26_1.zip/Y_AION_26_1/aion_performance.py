import pandas as pd
import warnings
warnings.filterwarnings("ignore")
import json
import os
import sys
from pandas.io.json import json_normalize
from evidently.dashboard import Dashboard
from evidently.tabs import ClassificationPerformanceTab
from aion_prediction import predict
def drift(data):
    try:
        features = '0,1,2,3,9,10,11,15,16,19,20,21,23,25,28,29,32,33,40,41,45,53,59,60,62,63,64,67,71,72,75,76,77,78,79,80,81,82,83,86,87,88,89,93,95,99,102,103,107,108,109,112,114,115,117,119,120,121,122,126,129,130,137,138,142,144,146,150,153,156,159,160,166,167,168,169,170,171,173,182,183,184,185,188,195,196,197,199,200,201,203,205,207,208,210,211,212,213,215,216,217,218,219,221,222,224,225,227,228,238,239,247,248,249,250,251,253,255,267,268,269,271,272,273,274,277,279,281,282,283,287,288,289,290,291,294,296,297,298,299,300,301,302,303,304,305,306,307,308,310,317,319,320,324,331,333,335,336,337,339,340,341,343,344,345,346,348,349,350,351,353,354,355,356,357,359,360,365,366,367,368,376,377,382,385,386,388,390,391,405,406,407,408,409,411,412,413,417,418,419,420,421,423,425,426,427,429,430,431,433,434,435,436,437,438,441,442,444,445,446,447,453,454,456,459,460,467,468,469,470,471,472,473,475,476,477,479,480,482,483,484,487,488,490,491,493,494,495,496,497,499,500,510,511,518,519,520,522,523,525,539,540,541,544,548,549,550,551,553,554,555,556,557,558,559,560,561,562,564,565,566,567,568,569,571,573,574,575,576,577,578,579,580,581,582,583,584,585,587,589'
        target = 'Pass/Fail'
        if os.path.splitext(data)[1] == ".json":
            with open(data,'r',encoding='utf-8') as f:
                jsonData = json.load(f)
        else:
            jsonData = json.loads(data)	
        production = predict(jsonData['currentDataLocation'])
        reference = predict(jsonData['trainingDataLocation'])
        production = json.loads(production)
        reference = json.loads(reference)
        if (production['status'] == 'SUCCESS' and reference['status'] == 'SUCCESS'):
                production = production['data']
                production = json_normalize(production)
                reference = reference['data']
                reference = json_normalize(reference)
                production['target'] = production[target]
                reference['target'] = reference[target]                
                iris_column_mapping = {}
                iris_column_mapping['target'] = 'target'
                iris_column_mapping['prediction'] = 'prediction'
                iris_column_mapping['numerical_features'] = features.split(',')
                iris_model_performance_dashboard = Dashboard(tabs=[ClassificationPerformanceTab])
                iris_model_performance_dashboard.calculate(reference, production, column_mapping = iris_column_mapping)
                report = os.path.join(os.path.dirname(os.path.abspath(__file__)),'reports','performance.html')
                iris_model_performance_dashboard.save(report)
                output = {"status":"SUCCESS","htmlPath":report}    
                print("drift:",json.dumps(output))
                return (json.dumps(output))
        else:
                output = {"status":"SUCCESS","htmlPath":'NA'}    
                print("drift:",json.dumps(output))
                return (json.dumps(output))        
         
    except KeyError as e:
        print(e)
        output = {"status":"FAIL","message":str(e).strip('"')}
        print("drift:",json.dumps(output))
        return (json.dumps(output))
    except Exception as e:
        print(e)
        output = {"status":"FAIL","message":str(e).strip('"')}
        print("drift:",json.dumps(output))
        return (json.dumps(output))

if __name__ == "__main__":
    output = drift(sys.argv[1])