from inputprofiler import inputprofiler
from selector import selector
def preprocessing(data):
	profilerobj = inputprofiler()
	data = profilerobj.apply_profiler(data)
	#selectobj = selector()
	#data = selectobj.apply_selector(data)
	data = data.astype(np.float32)    
	return(data)

import matplotlib.pyplot as plt
try:
	from sklearn.externals import joblib
except:
	import joblib    
import os,sys
import pandas as pd
from alibi.explainers import ALE,plot_ale
import io
import json
import urllib, base64
import numpy as np
from scipy.stats import linregress
from statistics import mean
import xgboost as xgb
import tensorflow as tf
tf.compat.v1.disable_eager_execution()

def get_ranked_values(explanation):
	ranked_shap_vals = []
	for cls_idx in range(len(explanation.shap_values)):
		this_ranking = (
			explanation.raw['importances'][str(cls_idx)]['ranked_effect'],
			explanation.raw['importances'][str(cls_idx)]['names']
			)
		ranked_shap_vals.append(this_ranking)

	return ranked_shap_vals
	
def feature_importance_using_shap(model,X,featuresNames,classes,x_test):
	from alibi.explainers import KernelShap
	import shap
	shap.initjs()
	if hasattr(model, "decision_function"):
		pred_fcn = model.decision_function
	elif hasattr(model, "predict_proba"):
		pred_fcn = model.predict_proba
	else:
		pred_fcn = model.predict
	svm_explainer = KernelShap(pred_fcn,feature_names=featuresNames)
	xtest = x_test[0].reshape(1, -1)
	svm_explainer.fit(X,n_background_samples=100)
	svm_explanation  = svm_explainer.explain(xtest)
	try:
		idx = 0
		instance = x_test[0][None, :]
		pred = model.predict(instance)
		class_idx = pred.item()
		if isinstance(svm_explainer.expected_value,np.ndarray):
			forceplot = shap.force_plot(svm_explainer.expected_value[class_idx],svm_explanation.shap_values[class_idx][idx,:],instance,feature_names=featuresNames,matplotlib=True,show=False)
		else:
			forceplot = shap.force_plot(svm_explainer.expected_value,svm_explanation.shap_values[0][idx,:],instance,feature_names=featuresNames,matplotlib=True,show=False)
		plt.tight_layout(pad = 0)
		image = io.BytesIO()
		plt.savefig(image, format='png')
		image.seek(0)
		string = base64.b64encode(image.read())          		
		image_64 = 'data:image/png;base64,' + urllib.parse.quote(string)
	except Exception as inst:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)
		print(str(exc_type)+' '+str(fname)+' '+str(exc_tb.tb_lineno))
		image_64 = ''
	try:
		plt.clf()
		if isinstance(svm_explainer.expected_value,np.ndarray):
			r = shap.multioutput_decision_plot(svm_explainer.expected_value.tolist(),
                                   svm_explanation.shap_values,
                                   idx,
                                   feature_names=featuresNames,
                                   feature_order='importance',
                                   highlight=[class_idx],
                                   legend_labels=classes,
                                   return_objects=True,
                                   legend_location='lower right',show=False)
		else:
			expectedvalues = [svm_explainer.expected_value]
			
			
			r = shap.multioutput_decision_plot(expectedvalues,
                                   svm_explanation.shap_values,
                                   idx,
                                   feature_names=featuresNames,
								   highlight = [0],
                                   return_objects=True,
                                   legend_labels=['Value'],
                                   feature_order='importance',
                                   show=False)
		plt.tight_layout(pad = 0)
		image = io.BytesIO()
		plt.savefig(image, format='png')
		image.seek(0)
		string = base64.b64encode(image.read())          		
		image2_64 = 'data:image/png;base64,' + urllib.parse.quote(string)
	except Exception as inst:
		print(inst)
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)
		print(str(exc_type)+' '+str(fname)+' '+str(exc_tb.tb_lineno))
		image2_64 = ''
							   
	return(image_64,image2_64)
	
	

	
def feature_importance(xtrain,ytrain,xfeatures,yfeature,problemType):
	if problemType == 'classification':
		from sklearn.feature_selection import SelectFromModel
		from sklearn.ensemble import ExtraTreesClassifier
		selector = SelectFromModel(ExtraTreesClassifier())
		selector.fit(xtrain,ytrain)
		values = selector.estimator_.feature_importances_
	elif problemType == 'regression':
		from sklearn.feature_selection import SelectFromModel
		from sklearn.linear_model import Lasso
		selector = SelectFromModel(Lasso())
		selector.fit(xtrain,ytrain)
		values = np.abs(selector.estimator_.coef_)
	labels = xtrain.columns.tolist()
	dft = pd.DataFrame()
	dft['labels'] = labels
	dft['values'] = values
	maxrecord = dft.iloc[dft['values'].argmax()]
	mostimportantfeature = maxrecord['labels']
	f_imp = dft.to_json(orient='records')
	return(f_imp,mostimportantfeature)

	
def get_trust_score(prdictfn,proba_fun,X_train,y_train):
	from alibi.confidence import TrustScore
	ts = TrustScore(k_filter=10,alpha=.05,filter_type='distance_knn',leaf_size=40,metric='euclidean',dist_filter_type='point')
	ts.fit(X_train, y_train, classes=3)
	y_pred  = prdictfn(X_train)
	#y_prod = proba_fun(X_train)
	#probas = y_prod[range(len(y_pred)), y_pred]
	score, closest_class = ts.score(X_train, y_pred,k=2,dist_type='point')
	return(mean(score))
	
def getCounterFactuals(model,prdictfn,features,x_train,categories):
	from alibi.explainers import CounterFactualProto
	cat_vars_ord = {}
	categoryList=categories.keys().tolist()
	categoryCountList=categories.tolist()
	for i in range(0,len(categoryCountList)):
		cat_vars_ord[categoryList[i]] = categoryCountList[i]
	print(cat_vars_ord)	
	X = x_train[0].reshape((1,) + x_train[0].shape)
	shape = X.shape
	print(shape)
	beta = .01
	c_init = 1.
	c_steps = 5
	max_iterations = 500
	rng = (-1., 1.)  # scale features between -1 and 1
	feature_range = (x_train.min(axis=0), x_train.max(axis=0))
	cf = CounterFactualProto(prdictfn,shape,cat_vars=cat_vars_ord)
	explanation = cf.explain(X)
	print(explanation)
	
def getAnchorTabularofFirstRecord(predict_fn,features,X_train,X_test,labelMap):
	from alibi.explainers import AnchorTabular
	explainer = AnchorTabular(predict_fn, features)
	explainer.fit(X_train.values)
	X_test = X_test.values
	anchors = []
	for idx in range(len(X_test)):	
		prediction = explainer.predictor(X_test[idx].reshape(1, -1))[0]
		if len(labelMap) > 0:
			predictionstr = list(labelMap.keys())[list(labelMap.values()).index(prediction)]
		else:
			predictionstr = prediction
		explanation = explainer.explain(X_test[idx],threshold=0.95)
		if str(explanation.anchor) == '[]':
			anchor = 'NA'
			precision  = explanation.precision[0]
		else:
			anchor = '%s' % (' AND '.join(explanation.anchor))
			precision  = explanation.precision
		coverage = explanation.coverage
		anchorjson = {}
		anchorjson['features'] = eval(str(features))
		anchorjson['values'] = eval(str(list(X_test[idx])))
		anchorjson['prediction'] = str(predictionstr)
		anchorjson['precision'] = str(round(precision,2))
		anchorjson['anchor'] = anchor
		anchors.append(anchorjson)
		print(anchors)
	try:
		return(json.dumps(anchors))
	except Exception as e:
		exc_type, exc_obj, exc_tb = sys.exc_info()
		fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)
		print(str(exc_type)+' '+str(fname)+' '+str(exc_tb.tb_lineno))
		return(json.dumps({}))
	
def ale_analysis():
	displaypath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"display.json")
	with open(displaypath) as file:
		config = json.load(file)
	file.close()
	model = joblib.load(os.path.join(os.path.dirname(os.path.abspath(__file__)),config['saved_model']))
	predict_fn = lambda x: model.predict(x)
	predictproba_fn = lambda x: model.predict_proba(x)
	dathPath = os.path.join(os.path.dirname(os.path.abspath(__file__)),'data','postprocesseddata.csv')	
	dataFrame=pd.read_csv(dathPath)
	
	testdathPath = os.path.join(os.path.dirname(os.path.abspath(__file__)),'data','predicteddata.csv')	
	testdataFrame=pd.read_csv(testdathPath)
	features = config['modelFeatures']#['SepalWidthCm','PetalLengthCm']

	targetfeature = config['targetFeature']#'Species'
	labelMap = config['labelMaps']
	targetData = dataFrame[targetfeature]
	if config['problemType'].lower() == 'regression':
		X_train = dataFrame[features]
		X_test = testdataFrame.head(5)
		X_test = X_test[features]
	else:
		valueCount=targetData.value_counts()
		categoryList=valueCount.keys().tolist()
		class_names = categoryList
		X_train = dataFrame[features]
		X_test = testdataFrame.groupby('predict').first().reset_index()
		X_test = X_test[features]
	f_imp,m_imp_f = feature_importance(X_train,targetData,features,targetfeature,config['problemType'].lower())
	if hasattr(model, "decision_function"):
		logit_fun_lr = model.decision_function
		try:
			logit_ale_lr = ALE(logit_fun_lr, feature_names=features, target_names=categoryList)
			logit_exp_lr = logit_ale_lr.explain(X_train.values) 
			values = logit_exp_lr.ale_values
			feature  = logit_exp_lr.feature_names 
			feature_values = logit_exp_lr.feature_values
			lines= []
			sentences = []
			for x in range(0,len(feature)):
				f_value = feature_values[x]
				value = values[x]
				lines= []
				for y in range(0,len(class_names)):
					line = []
					for z in value:
						cordinate = z[y]
						line.append(cordinate)
					lines.append(line)
				line = lines[0]
				slope1, intercept1, r_value, p_value, std_err = linregress(f_value,line)
				line = lines[1]
				slope2, intercept2, r_value, p_value, std_err = linregress(f_value,line)
				xi = (intercept1-intercept2) / (slope2-slope1)
				xi = round(xi,2)
				lastvalues = {}
				i = 0
				for line in lines:
					value = line[len(line)-1]
					lastvalues[class_names[i]] = value
					i = i+1
				Keymax = max(lastvalues, key=lastvalues.get)
				Keymin = min(lastvalues, key=lastvalues.get)
				Keymaxclass = list(labelMap.keys())[list(labelMap.values()).index(Keymax)]
				Keyminclass = list(labelMap.keys())[list(labelMap.values()).index(Keymin)]
				sentense = '<b>Effect of '+str(feature[x])+'</b><br>For data samples having  <b>'+str(feature[x])+'</b> >= <b>~'+str(xi)+'</b> ,there is a very high chance that they are of class <b>'+str(Keymaxclass)+'</b> '+targetfeature+'. For data samples having  <b>'+str(feature[x])+'</b> < <b>~'+str(xi)+'</b> there is a very high change that they are of class <b>'+str(Keyminclass)+'</b> '+targetfeature+'.'
				sentences.append(sentense)
		except:
			sentense = ''
			sentences.append(sentense)
			xi = 0
	elif hasattr(model, "predict_proba"):
		logit_fun_lr = model.predict_proba
		logit_ale_lr = ALE(logit_fun_lr, feature_names=features, target_names=categoryList)
		logit_exp_lr = logit_ale_lr.explain(X_train.values) 
		values = logit_exp_lr.ale_values
		feature  = logit_exp_lr.feature_names 
		feature_values = logit_exp_lr.feature_values
		lines= []
		sentences = []
		sentense = 'Graphs gives a feature value how much more(less) probability does the model assign to each class relative to mean prediction. This also means that any increase in relative probability of one class must result into a decrease in probability of another class.'
		sentences.append(sentense)
		xi = 0
	elif hasattr(model, "predict"):
		logit_fun_lr = model.predict
		logit_ale_lr = ALE(logit_fun_lr, feature_names=features, target_names=['Value'])
		logit_exp_lr = logit_ale_lr.explain(X_train.values) 
		values = logit_exp_lr.ale_values
		feature  = logit_exp_lr.feature_names 
		feature_values = logit_exp_lr.feature_values
		lines= []
		sentences = []
		sentense = 'The ALE value corresponding to that feature value is difference to the mean effect of that feature. Put differently, the ALE value is the relative feature effect on the prediction at that feature value.'
		sentences.append(sentense)
		xi = 0
	if (len(features)%2 ==0):
		n_cols = int(len(features)/2)
	else:
		n_cols = int(len(features)/2)+1
	figheight = n_cols*3
	try:
		plot_ale(logit_exp_lr,n_cols=2, fig_kw={'figwidth': 8, 'figheight': figheight})
		plt.tight_layout(pad = 0)
		image = io.BytesIO()
		plt.savefig(image, format='png')
		image.seek(0)
		string = base64.b64encode(image.read())          		
		image_64 = 'data:image/png;base64,' + urllib.parse.quote(string)
	except:
		image_64 = ''
	#score = get_trust_score(model.predict,proba_fun_lr,X_train.values,targetData.values)
	if config['problemType'].lower() == 'classification':
		anchorjson = getAnchorTabularofFirstRecord(predict_fn,features,X_train,X_test,labelMap)
	else:
		anchorjson = getAnchorTabularofFirstRecord(predict_fn,features,X_train,X_test,labelMap)
		#anchors=[]
		#anchorjson = json.dumps(anchors)
	#feature_importance_using_shap(model,X_train.values,features,class_names)
	#getCounterFactuals(model,predictproba_fn,features,X_train.values,valueCount)
	output_json = {"status":"SUCCESS","data":{"data":image_64,"most_influencedfeature":m_imp_f,"interceptionpoint":xi,"sentences":sentences,"feature_importance":json.loads(f_imp),"anchorjson":json.loads(anchorjson)}}
	output_json = json.dumps(output_json)
	print("aion_ai_explanation:",output_json)
	return(output_json)
    
def local_analysis(jsonData):
	jsonData = json.loads(jsonData)	
	displaypath = os.path.join(os.path.dirname(os.path.abspath(__file__)),"display.json")
	with open(displaypath) as file:
		config = json.load(file)
	file.close()
	model = joblib.load(os.path.join(os.path.dirname(os.path.abspath(__file__)),config['saved_model']))
	predict_fn = lambda x: model.predict(x)

	dathPath = os.path.join(os.path.dirname(os.path.abspath(__file__)),'data','postprocesseddata.csv')	
	dataFrame=pd.read_csv(dathPath)
	features = config['modelFeatures']#['SepalWidthCm','PetalLengthCm']

	targetfeature = config['targetFeature']#'Species'
	
	targetData = dataFrame[targetfeature]
	valueCount=targetData.value_counts()
	categoryList=valueCount.keys().tolist()
	class_names = categoryList
	#class_names = class_names.sort()	
	X_train = dataFrame[features]
	from pandas.io.json import json_normalize
	df_test = json_normalize(jsonData)	
	df_test = preprocessing(df_test)
	df_test = df_test[features]
	from alibi.explainers import AnchorTabular
	explainer = AnchorTabular(predict_fn, features)
	explainer.fit(X_train.values)
	df_test = df_test.values
	prediction = explainer.predictor(df_test.reshape(1, -1))[0]
	labelMap = config['labelMaps']
	if len(labelMap) > 0:
		prediction = list(labelMap.keys())[list(labelMap.values()).index(prediction)]
	else:
		prediction = str(prediction)    
	explanation = explainer.explain(df_test,threshold=0.85)
	if str(explanation.anchor) == '[]':
		anchor = 'NA'
		precision  = str(round(explanation.precision[0],2))
	else:
		anchor = '%s' % (' AND '.join(explanation.anchor))
		precision  = str(round(explanation.precision,2))
	coverage = explanation.coverage
	forceplot,multidecisionplot = feature_importance_using_shap(model,X_train.values,features,class_names,df_test)
	output_json = {"status":"SUCCESS","data":{"anchor":anchor,"precision":precision,"coverage":coverage,"prediction":prediction,"forceplot":forceplot,"multidecisionplot":multidecisionplot}}
	#print(output_json)
	output_json = json.dumps(output_json)
	print("aion_ai_explanation:",output_json)
	return(output_json)
if __name__ == '__main__':
	analysis_type = sys.argv[1]
	if analysis_type.lower() == 'global':
		ale_analysis()
	if analysis_type.lower() == 'local':
		data = 	sys.argv[2]	
		local_analysis(data)